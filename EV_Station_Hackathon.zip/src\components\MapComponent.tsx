import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { EVStation, Location } from '../types';
import { BatteryCharging, MapPin } from 'lucide-react';
import ReactDomServer from 'react-dom/server';

// Fix for default marker icons in Leaflet with React
const CustomMarkerIcon = (color: string) => L.divIcon({
    className: 'custom-icon',
    html: `<div style="background-color: ${color}; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 10px ${color}80; display: flex; align-items: center; justify-content: center;"><div style="width: 8px; height: 8px; background: white; border-radius: 50%;"></div></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12]
});

const UserLocationIcon = L.divIcon({
    className: 'user-icon',
    html: `<div style="background-color: #3b82f6; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 15px #3b82f6;"></div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10]
});

// Component to dynamically update map center
const ChangeView = ({ center }: { center: Location }) => {
    const map = useMap();
    useEffect(() => {
        map.setView([center.lat, center.lng], map.getZoom());
    }, [center, map]);
    return null;
};

interface Props {
    userLocation: Location | null;
    stations: EVStation[];
    onBook: (station: EVStation) => void;
}

export const MapComponent: React.FC<Props> = ({ userLocation, stations, onBook }) => {
    // Default to Bangalore
    const center: [number, number] = userLocation ? [userLocation.lat, userLocation.lng] : [12.9716, 77.5946];

    return (
        <div className="w-full h-full rounded-2xl overflow-hidden glass border-border-color border relative">
            <MapContainer
                center={center}
                zoom={13}
                style={{ height: '100%', width: '100%' }}
                zoomControl={false}
            >
                {/* CartoDB Dark Matter for premium dark aesthetic */}
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
                    url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
                />
                {userLocation && <ChangeView center={userLocation} />}

                {userLocation && (
                    <Marker position={[userLocation.lat, userLocation.lng]} icon={UserLocationIcon}>
                        <Popup>
                            <div className="font-bold text-black">Your Location</div>
                        </Popup>
                    </Marker>
                )}

                {stations.map(station => {
                    const isAvailable = station.availableSlots > 0;
                    const color = isAvailable ? '#10b981' : '#ef4444'; // green or red

                    return (
                        <Marker
                            key={station.id}
                            position={[station.location.lat, station.location.lng]}
                            icon={CustomMarkerIcon(color)}
                        >
                            <Popup className="custom-popup">
                                <div className="p-1 min-w-[200px]">
                                    <h3 className="font-bold text-lg mb-1">{station.name}</h3>
                                    <p className="text-sm opacity-80 mb-2 flex items-center gap-1">
                                        <MapPin size={12} /> {station.address}
                                    </p>

                                    <div className="flex justify-between items-center bg-gray-100 dark:bg-gray-800 p-2 rounded mb-3">
                                        <span className="text-xs font-semibold">Available Slots:</span>
                                        <span className={`font-bold ${isAvailable ? 'text-green-600' : 'text-red-500'}`}>
                                            {station.availableSlots} / {station.totalSlots}
                                        </span>
                                    </div>

                                    <button
                                        className={`w-full py-2 rounded font-bold text-sm text-white ${isAvailable ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-400 cursor-not-allowed'}`}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            if (isAvailable) onBook(station);
                                        }}
                                        disabled={!isAvailable}
                                    >
                                        {isAvailable ? 'Book Slot' : 'Full'}
                                    </button>
                                </div>
                            </Popup>
                        </Marker>
                    );
                })}
            </MapContainer>
        </div>
    );
};
