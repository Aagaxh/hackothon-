import React from 'react';
import { Zap, UserCircle } from 'lucide-react';

export const Header: React.FC = () => {
    return (
        <header className="glass sticky top-0 z-[1000] px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
                <div className="bg-accent-primary p-2 rounded-lg text-black animate-pulse-glow">
                    <Zap size={24} strokeWidth={2.5} />
                </div>
                <h1 className="text-xl font-bold tracking-tight">
                    Zap<span className="text-accent-primary">Charger</span>
                </h1>
            </div>

            <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
                <a href="#" className="text-text-primary hover:text-accent-primary transition-colors">Find Stations</a>
                <a href="#" className="text-text-secondary hover:text-white transition-colors">My Bookings</a>
                <a href="#" className="text-text-secondary hover:text-white transition-colors">Support</a>
            </nav>

            <div className="flex items-center gap-4">
                <button className="btn btn-secondary md:hidden">Menu</button>
                <div className="flex items-center gap-2 cursor-pointer hover:text-accent-primary transition-colors">
                    <UserCircle size={28} />
                    <span className="hidden md:inline font-medium">Profile</span>
                </div>
            </div>
        </header>
    );
};
