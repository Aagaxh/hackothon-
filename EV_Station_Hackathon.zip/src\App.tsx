import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MapComponent } from './components/MapComponent';
import { StationCard } from './components/StationCard';
import { ReservationModal } from './components/ReservationModal';
import { mockStations, calculateDistance } from './utils/mockData';
import { EVStation, Location } from './types';
import { CheckCircle2, Navigation2 } from 'lucide-react';

function App() {
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [stations, setStations] = useState<EVStation[]>(mockStations);
  const [selectedStation, setSelectedStation] = useState<EVStation | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [locating, setLocating] = useState(false);

  useEffect(() => {
    // Initial sort/distance calculation for default Bangalore location
    const defaultLoc = { lat: 12.9716, lng: 77.5946 };
    updateStationDistances(defaultLoc);
  }, []);

  const updateStationDistances = (loc: Location) => {
    const updated = mockStations.map(station => ({
      ...station,
      distance: calculateDistance(loc.lat, loc.lng, station.location.lat, station.location.lng)
    })).sort((a, b) => (a.distance || 0) - (b.distance || 0));
    setStations(updated);
  };

  const getUserLocation = () => {
    setLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const loc = { lat: position.coords.latitude, lng: position.coords.longitude };
          setUserLocation(loc);
          updateStationDistances(loc);
          setLocating(false);
        },
        (error) => {
          console.error('Error getting location', error);
          alert('Could not get your location. Displaying default center.');
          setLocating(false);
        }
      );
    } else {
      alert('Geolocation is not supported by your browser');
      setLocating(false);
    }
  };

  const handleConfirmBooking = (date: string, time: string, duration: number) => {
    // In a real app, this would hit an API
    setSelectedStation(null);
    setBookingSuccess(true);

    // Auto-hide success modal
    setTimeout(() => {
      setBookingSuccess(false);
    }, 4000);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6 max-w-7xl flex flex-col lg:flex-row gap-6 h-[calc(100vh-80px)]">

        {/* Left Side: Station List */}
        <div className="w-full lg:w-1/3 flex flex-col gap-4 h-full">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Nearby Stations</h2>
            <button
              onClick={getUserLocation}
              disabled={locating}
              className="btn btn-secondary text-xs px-3 py-1 flex items-center gap-1"
            >
              <Navigation2 size={14} className={locating ? 'animate-pulse' : ''} />
              {locating ? 'Locating...' : 'Locate Me'}
            </button>
          </div>

          <div className="overflow-y-auto flex-1 pr-2 flex flex-col gap-4 pb-10">
            {stations.map((station, idx) => (
              <StationCard
                key={station.id}
                station={station}
                index={idx}
                onBook={setSelectedStation}
              />
            ))}
            {stations.length === 0 && (
              <div className="text-text-secondary text-center py-10 glass-card">
                No stations found nearby.
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Map */}
        <div className="w-full lg:w-2/3 h-[50vh] lg:h-full min-h-[400px]">
          <MapComponent
            userLocation={userLocation}
            stations={stations}
            onBook={setSelectedStation}
          />
        </div>

      </main>

      {/* Reservation Modal */}
      {selectedStation && (
        <ReservationModal
          station={selectedStation}
          onClose={() => setSelectedStation(null)}
          onConfirm={handleConfirmBooking}
        />
      )}

      {/* Success Notification overlay */}
      {bookingSuccess && (
        <div className="fixed inset-0 z-[3000] flex items-center justify-center pointer-events-none p-4">
          <div className="glass-card animate-slide-up flex flex-col items-center justify-center p-8 text-center bg-black/80">
            <CheckCircle2 size={64} className="text-accent-primary mb-4" />
            <h2 className="text-3xl font-bold mb-2">Slot Confirmed!</h2>
            <p className="text-text-secondary">Your reservation has been successfully booked.</p>
          </div>
        </div>
      )}

    </div>
  );
}

export default App;
