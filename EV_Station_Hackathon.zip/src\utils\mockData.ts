import { EVStation } from '../types';

// Near Bangalore coordinates roughly (12.9716, 77.5946)
export const mockStations: EVStation[] = [
    {
        id: 'st-001',
        name: 'Zeus Fast Charge Center',
        location: { lat: 12.9720, lng: 77.5950 },
        address: 'MG Road, Bangalore',
        totalSlots: 8,
        availableSlots: 4,
        pricePerKwh: 18.5,
        amenities: ['Cafe', 'Restroom', 'WiFi'],
        powerOutput: '50kW DC'
    },
    {
        id: 'st-002',
        name: 'EcoVolt Hub',
        location: { lat: 12.9650, lng: 77.5900 },
        address: 'Residency Road, Bangalore',
        totalSlots: 5,
        availableSlots: 1,
        pricePerKwh: 15.0,
        amenities: ['Vending Machine'],
        powerOutput: '22kW AC'
    },
    {
        id: 'st-003',
        name: 'SparkPlug Station',
        location: { lat: 12.9780, lng: 77.6000 },
        address: 'Indiranagar, Bangalore',
        totalSlots: 10,
        availableSlots: 6,
        pricePerKwh: 20.0,
        amenities: ['Cafe', 'Shopping', 'Restroom'],
        powerOutput: '150kW DC'
    },
    {
        id: 'st-004',
        name: 'Voltway Express',
        location: { lat: 12.9680, lng: 77.6100 },
        address: 'Koramangala, Bangalore',
        totalSlots: 4,
        availableSlots: 0,
        pricePerKwh: 14.5,
        amenities: [],
        powerOutput: '22kW AC'
    },
    {
        id: 'st-005',
        name: 'ChargePoint Alpha',
        location: { lat: 12.9550, lng: 77.5850 },
        address: 'Jayanagar, Bangalore',
        totalSlots: 6,
        availableSlots: 3,
        pricePerKwh: 16.0,
        amenities: ['Restroom', 'Park'],
        powerOutput: '50kW DC'
    }
];

// Haversine formula to calculate mock distance
export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Radius of the earth in km
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c; // Distance in km
    return d;
};
