import React from 'react';
import { EVStation } from '../types';
import { BatteryCharging, MapPin, IndianRupee, Clock } from 'lucide-react';

interface Props {
    station: EVStation;
    onBook: (station: EVStation) => void;
    index?: number;
}

export const StationCard: React.FC<Props> = ({ station, onBook, index = 0 }) => {
    const isAvailable = station.availableSlots > 0;

    return (
        <div
            className={`glass-card animate-slide-up stagger-${(index % 3) + 1} flex flex-col gap-4`}
        >
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="font-bold text-lg">{station.name}</h3>
                    <p className="text-text-secondary text-sm flex items-center gap-1 mt-1">
                        <MapPin size={14} />
                        {station.address}
                        {station.distance && ` • ${station.distance.toFixed(1)} km`}
                    </p>
                </div>
                <div className={`px-2 py-1 rounded text-xs font-bold ${isAvailable ? 'bg-accent-primary text-black' : 'bg-error text-white'
                    }`}>
                    {isAvailable ? 'Available' : 'Full'}
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-2">
                <div className="flex items-center gap-2">
                    <BatteryCharging className="text-accent-primary" size={20} />
                    <div>
                        <p className="text-xs text-text-secondary">Power Output</p>
                        <p className="font-semibold">{station.powerOutput}</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <div className="bg-bg-tertiary p-1.5 rounded-full text-text-secondary">
                        <dt className="sr-only">Slots</dt>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2" /><line x1="12" y1="8" x2="12" y2="16" /><line x1="8" y1="12" x2="16" y2="12" /></svg>
                    </div>
                    <div>
                        <p className="text-xs text-text-secondary">Slots open</p>
                        <p className="font-semibold">{station.availableSlots} <span className="text-text-secondary font-normal">/ {station.totalSlots}</span></p>
                    </div>
                </div>
            </div>

            <div className="border-t border-border-color pt-4 flex items-center justify-between">
                <div className="flex items-center gap-1">
                    <IndianRupee size={16} className="text-text-secondary" />
                    <span className="font-bold text-xl">{station.pricePerKwh.toFixed(2)}</span>
                    <span className="text-text-secondary text-sm">/ kWh</span>
                </div>

                <button
                    className={`btn ${isAvailable ? 'btn-primary' : 'bg-bg-tertiary text-text-secondary cursor-not-allowed border border-border-color'} px-6`}
                    onClick={() => isAvailable && onBook(station)}
                    disabled={!isAvailable}
                >
                    {isAvailable ? 'Book Slot' : 'Unavailable'}
                </button>
            </div>
        </div>
    );
};
