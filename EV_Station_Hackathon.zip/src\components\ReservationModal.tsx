import React, { useState } from 'react';
import { EVStation } from '../types';
import { X, Calendar, Clock, IndianRupee } from 'lucide-react';

interface Props {
    station: EVStation;
    onClose: () => void;
    onConfirm: (date: string, time: string, duration: number) => void;
}

export const ReservationModal: React.FC<Props> = ({ station, onClose, onConfirm }) => {
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [duration, setDuration] = useState(1);

    const estimatedEnergy = duration * (parseInt(station.powerOutput) || 22);
    const estimatedCost = estimatedEnergy * station.pricePerKwh;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (date && time) {
            onConfirm(date, time, duration);
        }
    };

    return (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in p-4">
            <div className="glass-card w-full max-w-md animate-slide-up relative overflow-hidden">
                {/* Decorative background glow */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-accent-glow rounded-full blur-3xl -z-10 transform translate-x-1/2 -translate-y-1/2"></div>

                <button
                    onClick={onClose}
                    className="absolute top-4 right-4 text-text-secondary hover:text-white transition-colors"
                >
                    <X size={24} />
                </button>

                <h2 className="text-2xl font-bold mb-1">Reserve Slot</h2>
                <p className="text-text-secondary text-sm mb-6">{station.name}</p>

                <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="flex flex-col gap-2">
                            <label className="text-sm font-medium flex items-center gap-1">
                                <Calendar size={16} /> Date
                            </label>
                            <input
                                type="date"
                                required
                                min={new Date().toISOString().split('T')[0]}
                                value={date}
                                onChange={(e) => setDate(e.target.value)}
                                className="bg-bg-tertiary border border-border-color rounded-md px-3 py-2 text-white focus:outline-none focus:border-accent-primary transition-colors"
                            />
                        </div>
                        <div className="flex flex-col gap-2">
                            <label className="text-sm font-medium flex items-center gap-1">
                                <Clock size={16} /> Time
                            </label>
                            <input
                                type="time"
                                required
                                value={time}
                                onChange={(e) => setTime(e.target.value)}
                                className="bg-bg-tertiary border border-border-color rounded-md px-3 py-2 text-white focus:outline-none focus:border-accent-primary transition-colors"
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-2">
                        <label className="text-sm font-medium">Duration: {duration} Hour{duration > 1 ? 's' : ''}</label>
                        <input
                            type="range"
                            min="1"
                            max="4"
                            step="0.5"
                            value={duration}
                            onChange={(e) => setDuration(parseFloat(e.target.value))}
                            className="w-full accent-accent-primary bg-bg-tertiary h-2 rounded-lg appearance-none cursor-pointer"
                        />
                    </div>

                    <div className="mt-4 p-4 bg-bg-primary/50 border border-border-color rounded-lg flex flex-col gap-2">
                        <div className="flex justify-between text-sm">
                            <span className="text-text-secondary">Est. Energy Delivery</span>
                            <span className="font-semibold">{estimatedEnergy} kWh</span>
                        </div>
                        <div className="flex justify-between text-sm">
                            <span className="text-text-secondary">Price Rate</span>
                            <span className="font-semibold">₹{station.pricePerKwh.toFixed(2)} / kWh</span>
                        </div>
                        <div className="border-t border-border-color my-1"></div>
                        <div className="flex justify-between items-center mt-1">
                            <span className="font-medium">Total Estimate</span>
                            <span className="font-bold text-xl flex items-center text-accent-primary">
                                <IndianRupee size={20} />
                                {estimatedCost.toFixed(2)}
                            </span>
                        </div>
                    </div>

                    <button type="submit" className="btn btn-primary w-full mt-2 py-3 rounded-lg text-lg">
                        Confirm Reservation
                    </button>
                </form>
            </div>
        </div>
    );
};
