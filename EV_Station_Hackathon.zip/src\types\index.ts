export interface Location {
    lat: number;
    lng: number;
}

export interface EVStation {
    id: string;
    name: string;
    location: Location;
    address: string;
    distance?: number; // Calculated distance
    totalSlots: number;
    availableSlots: number;
    pricePerKwh: number; // In INR
    amenities: string[];
    powerOutput: string; // e.g., "50kW DC", "22kW AC"
}

export interface Reservation {
    id: string;
    stationId: string;
    date: string;
    time: string;
    duration: number; // in hours
    totalCost: number; // In INR
    status: 'confirmed' | 'pending' | 'cancelled';
}
